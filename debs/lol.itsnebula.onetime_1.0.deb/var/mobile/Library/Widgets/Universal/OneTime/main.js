function changeStuff() {
    const element = document.getElementById('time')
    const now = new Date().toLocaleTimeString('en-US',{ hour: "2-digit" })
    const minutenow = new Date().toLocaleTimeString('en-US',{ minute: "2-digit" })
    const partshr = now.split(" ")
    const partsmn = minutenow.split(" ")

    let hr = partshr[0];
    element.innerHTML = "<span style='color: " + config.hourColor + "'>" + hr + "</span><br>" + "<span style='color: " + config.minuteColor + "'>" + partsmn[0] + "</span>"
}

function initTime(){
    changeStuff()
    setInterval(changeStuff, 1000)
}
